﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS311C_DATABASE2024
{
    public partial class frmNewstudent : Form
    {
        private int errorCount;
        private string level, username;

        public frmNewstudent(string username)
        {
            InitializeComponent();
            this.username = username;
            cmblevel.SelectedIndexChanged += new EventHandler(cmblevel_SelectedIndexChanged);
        }
        Class1 Newstudents = new Class1("127.0.0.1", "cs311c2024", "nathanielkester", "bueno");
        private void frmNewstudent_Load(object sender, EventArgs e)
        {
            
        }


        private void validateForm()
        {
            errorProvider1.Clear();
            errorCount = 0;
            if (string.IsNullOrEmpty(txtstudentid.Text))
            {
                errorProvider1.SetError(txtstudentid, "Student ID is empty!");
                errorCount++;
            }
            if (string.IsNullOrEmpty(txtfirstname.Text))
            {
                errorProvider1.SetError(txtfirstname, "First name is empty!");
                errorCount++;
            }
            if (string.IsNullOrEmpty(txtlastname.Text))
            {
                errorProvider1.SetError(txtlastname, "Last name is empty!");
                errorCount++;
            }
            if (cmbcourse.SelectedIndex == -1)
            {
                errorProvider1.SetError(cmbcourse, "No course/strand selected!");
                errorCount++;
            }
            try
            {
                DataTable dt = Newstudents.GetData("SELECT * FROM tblstudents WHERE studentID = '" + txtstudentid.Text + "'");
                if (dt.Rows.Count > 0)
                {
                    errorProvider1.SetError(txtstudentid, "Student ID already exists");
                    errorCount++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        

     

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtstudentid.Clear();
            txtlastname.Clear();
            txtfirstname.Clear();
            txtmiddlename.Clear();
            cmblevel.SelectedIndex = -1;
            cmbcourse.SelectedIndex = -1;
            errorProvider1.Clear();
        }

        private void cmbcourse_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmblevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Clear the strand/course combo box
            cmbcourse.DataSource = null;
            cmbcourse.Items.Clear();

            // Ensure the level combo box has a selected item
            if (cmblevel.SelectedItem != null)
            {
                string selectedLevel = cmblevel.SelectedItem.ToString();

                // If the level is ELEM or JHS, set "N / A" as the only option and disable cmbSC
                if (selectedLevel == "ELEM" || selectedLevel == "JHS")
                {
                    cmbcourse.Items.Add("N / A");
                    cmbcourse.SelectedIndex = 0;  // Automatically select "N / A"
                    cmbcourse.Enabled = false; // Disable the combo box
                }

                // If the level is SHS, enable and populate cmbSC with strands from the database
                if (selectedLevel == "SHS")
                {
                    cmbcourse.Enabled = true;
                    DataTable dtStrands = Newstudents.GetData("SELECT strandcode AS Code, description FROM tblstrands");
                    cmbcourse.DataSource = dtStrands;
                    cmbcourse.DisplayMember = "description"; // Show description in the dropdown
                    cmbcourse.ValueMember = "Code"; // Use the strand code as value
                    cmbcourse.SelectedIndex = -1; // Set no initial selection
                }
                // If the level is COLLEGE, enable and populate cmbSC with courses from the database
                else if (selectedLevel == "COLLEGE")
                {
                    cmbcourse.Enabled = true;
                    DataTable dtCourses = Newstudents.GetData("SELECT coursecode AS Code, description FROM tblcourses");
                    cmbcourse.DataSource = dtCourses;
                    cmbcourse.DisplayMember = "description"; // Show description in the dropdown
                    cmbcourse.ValueMember = "Code"; // Use the course code as value
                    cmbcourse.SelectedIndex = -1; // Set no initial selection
                }
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {

            validateForm();
            if (errorCount == 0)
            {
                // Confirm if the user wants to add the new student
                DialogResult dr = MessageBox.Show("Are you sure you want to Add this Student?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    string selectedCourseCode = "N / A"; // Default to N / A

                    // Check if the level is SHS or COLLEGE, then use the selected value from cmbSC
                    if (cmblevel.SelectedItem.ToString() == "SHS" || cmblevel.SelectedItem.ToString() == "COLLEGE")
                    {
                        selectedCourseCode = cmbcourse.SelectedValue?.ToString(); // Use the selected course or strand code
                    }

                    // Insert the new student into the database, using the course/strand code
                    Newstudents.executeSQL("INSERT INTO tblstudents (studentID, lastname, firstname, middlename, level, course, createdby, datecreated) VALUES ('" +
                        txtstudentid.Text + "', '" + txtlastname.Text + "', '" + txtfirstname.Text + "', '" + txtmiddlename.Text + "', '" + cmblevel.Text + "','" +
                        selectedCourseCode + "', '" + username + "', '" + DateTime.Now.ToShortDateString() + "')");

                    // Check if the insert operation affected any rows
                    if (Newstudents.rowAffected > 0)
                    {
                        // Log the action in the logs table
                        Newstudents.executeSQL("INSERT INTO tbllogs (datelog, timelog, action, module, ID, performedby) VALUES ('" +
                            DateTime.Now.ToShortDateString() + "', '" + DateTime.Now.ToShortTimeString() + "', 'ADD', 'Student Management', '" +
                            txtstudentid.Text + "', '" + username + "')");

                        // Show success message and close the form
                        MessageBox.Show("New Student Successfully Added", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close(); // Close the form
                    }
                    else
                    {
                        // Show error message if the insertion failed
                        MessageBox.Show("Failed to add the Student. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }        
}
