﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS311C_DATABASE2024
{
    public partial class FrmNewViolation : Form
    {
        private string username;
        private int errorCount;
        Class1 newviolations = new Class1("127.0.0.1", "cs311c2024", "nathanielkester", "bueno");
        public FrmNewViolation(string username)
        {
            InitializeComponent();
            this.username = username;
        }
        private void validateForm()
        {
            errorProvider1.Clear();
            errorCount = 0;
            if (string.IsNullOrEmpty(txtcode.Text))
            {
                errorProvider1.SetError(txtcode, "Violation code is empty!");
                errorCount++;
            }
            if (string.IsNullOrEmpty(txtdescription.Text))
            {
                errorProvider1.SetError(txtdescription, "Violation description is empty!");
                errorCount++;
            }
            if (cmbtype.SelectedIndex < 0)
            {
                errorProvider1.SetError(cmbtype, "Select offense type");
                errorCount++;
            }
            try
            {
                DataTable dt = newviolations.GetData("SELECT * FROM tblviolations WHERE code = '" + txtcode.Text + "'");
                if (dt.Rows.Count > 0)
                {
                    errorProvider1.SetError(txtcode, "Violation code already exists");
                    errorCount++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmNewViolation_Load(object sender, EventArgs e)
        {
            txtcode.Text = "Violation: " + DateTime.Now.ToString("yyyy/MM/dd/H/m/s");
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            validateForm();
            if (errorCount == 0)
            {
                try
                {
                    DialogResult dr = MessageBox.Show("Are you sure you want to add this violation?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dr == DialogResult.Yes)
                    {
                        newviolations.executeSQL("INSERT INTO tblviolations (code, description, type, status, createdby, datecreated) VALUES ('" + txtcode.Text + "','" + txtdescription.Text + "','" + cmbtype.Text.ToUpper() + "','ACTIVE','" + username + "','" + DateTime.Now.ToShortDateString() + "')");
                        if (newviolations.rowAffected > 0)
                        {
                            newviolations.executeSQL("INSERT INTO tbllogs (datelog, timelog, action, module, ID, performedby) VALUES ('" + DateTime.Now.ToShortDateString() + "','" + DateTime.Now.ToShortTimeString() +
                                "','Add', 'Violations Management', '" + txtcode.Text + "','" + username + "')");
                            MessageBox.Show("New Violation Added", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            errorCount = 0;
            errorProvider1.Clear();
            txtdescription.Clear();
            cmbtype.SelectedIndex = -1;
        }

        private void txtcode_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
