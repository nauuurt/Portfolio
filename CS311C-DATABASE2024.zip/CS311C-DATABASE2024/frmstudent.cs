﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS311C_DATABASE2024
{
    public partial class frmstudent : Form
    {
        private string username;
        private int row;
        public frmstudent(string username)
        {
            InitializeComponent();
            this.username = username;
        }
        Class1 students = new Class1("127.0.0.1", "cs311c2024", "nathanielkester", "bueno");
        private void frmstudent_Load(object sender, EventArgs e)
        {
            try
            {
                // Fetch and display student data excluding the current user's ID
                DataTable dt = students.GetData("SELECT studentID, lastname, firstname, middlename, level, course, datecreated, createdby FROM tblstudents WHERE studentID <> '" + username + "' ORDER BY studentID");
                dataGridView1.DataSource = dt; // Set the data source for the DataGridView
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                // Show error message if fetching data fails
                MessageBox.Show(ex.Message, "Error on students load", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = students.GetData("SELECT studentID, lastname, firstname, middlename, level, course, datecreated, createdby FROM tblstudents WHERE studentID <> '" + students +
                    "' AND (studentID LIKE '%" + txtsearch.Text + "%' OR lastname LIKE '%" + txtsearch.Text + "%'  OR course LIKE '%" + txtsearch.Text + "%' OR level LIKE '%" + txtsearch.Text + "%') ORDER BY studentID");
                dataGridView1.DataSource = dt; // Update the data source with the search results
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            frmNewstudent newstudent = new frmNewstudent(username);
            newstudent.Show();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to delete this student?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                string selectedstudent = dataGridView1.Rows[row].Cells[0].Value.ToString();
                try
                {
                    students.executeSQL("DELETE FROM tblstudents WHERE studentID = '" + selectedstudent + "'");
                    if (students.rowAffected > 0)
                    {
                        students.executeSQL("INSERT INTO tbllogs (datelog, timelog, action, module, ID, performedby) VALUES ('" + DateTime.Now.ToShortDateString() + "','" + DateTime.Now.ToShortTimeString() +
                            "','Delete', 'Students Management', '" + selectedstudent + "','" + username + "')");
                        MessageBox.Show("Student Deleted", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
                frmstudent_Load(sender, e);
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                row = (int)e.RowIndex;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error on datagrid cellclick", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string editstudentID = dataGridView1.Rows[row].Cells[0].Value.ToString();
            string editlastname = dataGridView1.Rows[row].Cells[1].Value.ToString();
            string editfirstname = dataGridView1.Rows[row].Cells[2].Value.ToString();
            string editmiddlename = dataGridView1.Rows[row].Cells[3].Value.ToString();
            string editlevel = dataGridView1.Rows[row].Cells[4].Value.ToString();
            string editcourse = dataGridView1.Rows[row].Cells[5].Value.ToString();
            frmUpdateStudent updatestudentfrm = new frmUpdateStudent(editstudentID, editlastname, editfirstname, editmiddlename, editlevel, editcourse, username);
            updatestudentfrm.Show();
        }


        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                row = (int)e.RowIndex;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " Error on update", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
