﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS311C_DATABASE2024
{
    public partial class frmMain : Form
    {
        private string username, usertype;

        public frmMain(string username, string usertype)
        {
            InitializeComponent();
            this.username = username;
            this.usertype = usertype;
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            frmlogin loginform = new frmlogin();
            loginform.Show();
        }

        private void accountsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAccounts accountsform = new frmAccounts(username);
            accountsform.MdiParent = this;
            accountsform.Show();
        }

        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmstudent studentsform = new frmstudent(username);
            studentsform.MdiParent = this;
            studentsform.Show();
        }

        private void studentsToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmstudent studentsform = new frmstudent(username);
            studentsform.MdiParent = this;
            studentsform.Show();
        }

        private void courseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCourse courseForm = new frmCourse(username);
            courseForm.MdiParent = this;
            courseForm.Show();
        }

        private void strandToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmStrands strands = new FrmStrands(username);
            strands.MdiParent = this;
            strands.Show();
        }

        private void violationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmViolation violation = new FrmViolation(username);
            violation.MdiParent = this;
            violation.Show();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = " USERNAME: " + username;
            toolStripStatusLabel2.Text = " USERTYPE: " + usertype;
            if (usertype == "ADMINISTRATOR")
            {
                accountsToolStripMenuItem.Visible = true;
                studentsToolStripMenuItem.Visible = true;
                violationToolStripMenuItem.Visible = true;
            }
            else if (usertype =="BRANCH ADMINISTRATOR")
            {
                accountsToolStripMenuItem.Visible = true;
                studentsToolStripMenuItem.Visible = true;
                violationToolStripMenuItem.Visible = true;
            }
            else
            {
                accountsToolStripMenuItem.Visible = false;
                studentsToolStripMenuItem.Visible = true;
                violationToolStripMenuItem.Visible = true;
            }              
        }
    }
}
