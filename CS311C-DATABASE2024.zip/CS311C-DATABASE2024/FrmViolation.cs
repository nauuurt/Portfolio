﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS311C_DATABASE2024
{
    public partial class FrmViolation : Form
    {
        private int row;
        private string username;
        public FrmViolation(string username)
        {
            InitializeComponent();
            this.username = username;
        }
        Class1 violations = new Class1("127.0.0.1", "cs311c2024", "nathanielkester", "bueno");

        private void FrmViolation_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = violations.GetData("SELECT code, description, type, status, createdby, datecreated FROM tblviolations WHERE code <> '" + username + "'ORDER BY code");
                dataGridView1.DataSource = dt;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error on violation load", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            FrmNewViolation newViolation = new FrmNewViolation(username);
            newViolation.ShowDialog();
        }



        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                row = (int)e.RowIndex;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " Error on row", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = violations.GetData("SELECT code, description , type, status, createdby, datecreated  FROM tblviolations WHERE (code LIKE '%" + txtsearch.Text + "%' OR description LIKE '%" + txtsearch.Text +
                    "%' OR type LIKE '%" + txtsearch.Text + "%' OR status LIKE '%" + txtsearch.Text + "%') ORDER BY code");
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error on search", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to delete this violation?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                string selectedviolation = dataGridView1.Rows[row].Cells[0].Value.ToString();
                try
                {
                    violations.executeSQL("DELETE FROM tblviolations WHERE code = '" + selectedviolation + "'");
                    if (violations.rowAffected > 0)
                    {
                        violations.executeSQL("INSERT INTO tbllogs (datelog, timelog, action, module, ID, performedby) VALUES ('" + DateTime.Now.ToShortDateString() + "', '" +
                                DateTime.Now.ToShortTimeString() + "', 'DELETE', 'Violations Management', '" + selectedviolation + "', '" + username + "' )");
                        MessageBox.Show("Account Deleted", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        FrmViolation_Load(sender, e);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error on delete", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            FrmViolation_Load(sender, e);
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
           
            string editcode = dataGridView1.Rows[row].Cells[0].Value.ToString();
            string editdescription = dataGridView1.Rows[row].Cells[1].Value.ToString();
            string edittype = dataGridView1.Rows[row].Cells[2].Value.ToString();
            string editstatus = dataGridView1.Rows[row].Cells[3].Value.ToString();

            FrmUpdateValidation violateupdate = new FrmUpdateValidation(editcode, editdescription, edittype, editstatus, username);
            violateupdate.Show();
            
        }
        
    }
}
