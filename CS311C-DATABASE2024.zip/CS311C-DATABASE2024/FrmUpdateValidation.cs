﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS311C_DATABASE2024
{
    public partial class FrmUpdateValidation : Form
    {
        private string editcode, editdescription, editstatus, username, status, edittype;
        private int errorcount;
        Class1 updateviolations = new Class1("127.0.0.1", "cs311c2024", "nathanielkester", "bueno");
        public FrmUpdateValidation(string editcode, string editdescription, string edittype, string editstatus, string username)
        {
            InitializeComponent();
            this.editcode = editcode;
            this.editdescription = editdescription;
            this.editstatus = editstatus;
            this.username = username;
            this.edittype = edittype;
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            validateform();
            if (errorcount == 0)
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to Update this account?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    try
                    {
                        updateviolations.executeSQL("UPDATE tblviolations SET description = '" + txtdescription.Text + "', type = '" + cmbtype.Text.ToUpper() + "', status = '" + cmbstatus.Text.ToUpper() + "' WHERE code = '" + txtcode.Text + "'");
                        if (updateviolations.rowAffected > 0)
                        {
                            updateviolations.executeSQL("INSERT INTO tbllogs (datelog, timelog, action, module, ID, performedby) VALUES ('" + DateTime.Now.ToShortDateString() + "', '" +
                                DateTime.Now.ToShortTimeString() + "', 'UPDATE', 'Violations Management', '" + txtcode.Text + "', '" + username + "' )");
                            MessageBox.Show("Violations updated", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error on save", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        public void validateform()
        {

            errorProvider1.Clear();
            errorcount = 0;
            if (string.IsNullOrEmpty(txtdescription.Text))
            {
                errorProvider1.SetError(txtdescription, "Description  is empty");
                errorcount++;
            }
            if (cmbtype.SelectedIndex < 0)
            {
                errorProvider1.SetError(cmbtype, "Select Type");
                errorcount++;
            }
            if (cmbstatus.SelectedIndex < 0)
            {
                errorProvider1.SetError(cmbtype, "Select Status");
                errorcount++;
            }
        }
        private void FrmUpdateValidation_Load(object sender, EventArgs e)
        {
            txtcode.Text = editcode;
            txtdescription.Text = editdescription;
            if (edittype == "MAJOR OFFENSE")
            {
                cmbtype.SelectedIndex = 0;
            }
            else
            {
                cmbtype.SelectedIndex = 1;
            }

            if (editstatus == "ACTIVE")
            {
                cmbstatus.SelectedIndex = 0;
            }
            else
            {
                cmbstatus.SelectedIndex = 1;
            }
        }

    }
}
