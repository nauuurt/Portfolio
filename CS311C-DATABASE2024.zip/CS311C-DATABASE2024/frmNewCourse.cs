﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace CS311C_DATABASE2024
{
    public partial class frmNewCourse : Form
    {
        private string username;
        private int errorcount;
        public frmNewCourse(string username)
        {
            InitializeComponent();
            this.username = username;
        }
        Class1 newcourse = new Class1("127.0.0.1", "cs311c2024", "nathanielkester", "bueno");

        private void validateForm()
        {
            errorProvider1.Clear();
            errorcount = 0;
            if (string.IsNullOrEmpty(txtcoursecode.Text))
            {
                errorProvider1.SetError(txtcoursecode, "Course code is empty!");
                errorcount++;
            }
            if (string.IsNullOrEmpty(txtdescription.Text))
            {
                errorProvider1.SetError(txtdescription, "Course description is empty!");
                errorcount++;
            }
            try
            {
                DataTable dt = newcourse.GetData("SELECT * FROM tblcourses WHERE coursecode = '" + txtcoursecode.Text + "'");
                if (dt.Rows.Count > 0)
                {
                    errorProvider1.SetError(txtcoursecode, "Code is already in use!");
                    errorcount++;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }
        private void frmNewCourse_Load(object sender, EventArgs e)
        {
            
        }
        private void Placeholder_Enter(object sender, EventArgs e)
        {
            TextBox txtBox = sender as TextBox;

            if (txtBox != null && txtBox.Tag != null && txtBox.Text == txtBox.Tag.ToString())
            {
                txtBox.Text = "";
                txtBox.ForeColor = Color.Black; // Text color when the user starts typing
            }
        }

        private void Placeholder_Leave(object sender, EventArgs e)
        {
            TextBox txtBox = sender as TextBox;

            if (txtBox != null && txtBox.Tag != null && txtBox.Text == "")
            {
                txtBox.Text = txtBox.Tag.ToString();
                txtBox.ForeColor = Color.Silver; // Placeholder color
            }
        }

    

        private void btnsave_Click(object sender, EventArgs e)
        {       
            validateForm();
            if (errorcount == 0)
            {
                DialogResult dr = MessageBox.Show("Are you sure you want to add this course?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    try
                    {
                        newcourse.executeSQL("INSERT INTO tblcourses (coursecode, description, createdby, datecreated) VALUES ('" + txtcoursecode.Text.ToUpper() +
                            "', '" + txtdescription.Text + "','" + username + "' , '" + DateTime.Now.ToShortDateString() + "')");
                        if (newcourse.rowAffected > 0)
                        {
                            newcourse.executeSQL("INSERT INTO tbllogs (datelog, timelog, action, module, ID, performedby) VALUES ('" + DateTime.Now.ToShortDateString() +
                                "', '" + DateTime.Now.ToShortTimeString() + "', 'ADD', 'Course Management', '" + txtcoursecode.Text + "', '" + username + "')");
                            MessageBox.Show("New course Added", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error on Validating existing course code", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtcoursecode.Clear();
            txtdescription.Clear();
            txtcoursecode.Focus();
            errorProvider1.Clear();
        }

     

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
