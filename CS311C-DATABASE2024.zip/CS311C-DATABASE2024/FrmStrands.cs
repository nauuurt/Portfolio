﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS311C_DATABASE2024
{
    public partial class FrmStrands : Form
    {
        private string username;
        private int row;
        public FrmStrands(string username)
        {
            InitializeComponent();
            this.username = username;
        }
        Class1 strand = new Class1("127.0.0.1", "cs311c2024", "nathanielkester", "bueno");
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                row = (int)e.RowIndex;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error on datgrid cellclick", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmStrands_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = strand.GetData("Select strandcode, description, createdby, datecreated FROM tblstrands WHERE strandcode <> '" +
                    username + "' ORDER BY strandcode");
                dataGridView1.DataSource = dt;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error on Strands", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            FrmStrands_Load(sender, e);
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure you want to delete this strand?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                string selectedUser = dataGridView1.Rows[row].Cells[0].Value.ToString();
                try
                {
                    strand.executeSQL("DELETE FROM tblstrands WHERE strandcode = '" + selectedUser + "'");
                    if (strand.rowAffected > 0)
                    {
                        strand.executeSQL("INSERT INTO tbllogs (datelog, timelog, action, module, ID, performedby) VALUES ('" + DateTime.Now.ToShortDateString() +
                                "', '" + DateTime.Now.ToShortTimeString() + "', 'DELETE', 'Strand Management', '" + selectedUser + "', '" + username + "')");
                        MessageBox.Show("Strand Deleted", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error on delete", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = strand.GetData("Select strandcode, description, createdby, datecreated FROM tblstrands WHERE strandcode <> '" + username +
                    "' AND (strandcode LIKE '%" + txtsearch.Text + "%' OR description LIKE '%" + txtsearch.Text + "%') ORDER BY strandcode");
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error on search", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            FrmNewStrand newstrand = new FrmNewStrand(username);
            newstrand.Show();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string editstrandcode = dataGridView1.Rows[row].Cells[0].Value.ToString();
            string editdecription = dataGridView1.Rows[row].Cells[1].Value.ToString();
            FrmUpdateStrand updatestrand = new FrmUpdateStrand(editstrandcode, editdecription, username);
            updatestrand.Show();
        }
    }
}
