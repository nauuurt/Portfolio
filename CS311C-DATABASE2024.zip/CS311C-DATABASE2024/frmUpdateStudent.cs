﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CS311C_DATABASE2024
{
    public partial class frmUpdateStudent : Form
    {
        private int errorCount;
        private string studentID, editstudentID, editlastname, editfirstname, editmiddlename, editlevel, editcourse, username, level, description;

        private void cmblevel_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Clear cmbSC (Strand/Course) items
            cmbcourse.DataSource = null;
            cmbcourse.Items.Clear();

            // Ensure the level combo box has a selected item
            if (cmblevel.SelectedItem != null)
            {
                string selectedLevel = cmblevel.SelectedItem.ToString();
                cmbcourse.Enabled = selectedLevel == "SHS" || selectedLevel == "COLLEGE";

                if (selectedLevel == "ELEM" || selectedLevel == "JHS")
                {
                    cmbcourse.Items.Add("N / A");
                    cmbcourse.SelectedIndex = 0;  // Automatically select "N / A"
                    cmbcourse.Enabled = false;    // Disable cmbSC since it's not needed
                }
                else if (selectedLevel == "SHS")
                {
                    DataTable dtStrands = updatestudents.GetData("SELECT strandcode AS Code, description FROM tblstrands");
                    cmbcourse.DataSource = dtStrands;
                    cmbcourse.DisplayMember = "description"; // Show description in the dropdown
                    cmbcourse.ValueMember = "Code"; // Use the strand code as value
                    cmbcourse.SelectedIndex = -1; // Set no initial selection
                }
                else if (selectedLevel == "COLLEGE")
                {
                    DataTable dtCourses = updatestudents.GetData("SELECT coursecode AS Code, description FROM tblcourses");
                    cmbcourse.DataSource = dtCourses;
                    cmbcourse.DisplayMember = "description"; // Show description in the dropdown
                    cmbcourse.ValueMember = "Code"; // Use the course code as value
                    cmbcourse.SelectedIndex = -1; // Set no initial selection
                }
            }
        }

        public frmUpdateStudent(string editstudentID, string editlastname, string editfirstname, string editmiddlename, string editlevel, string editcourse, string username)
        {
            InitializeComponent();
            this.editstudentID = editstudentID;
            this.editlastname = editlastname;
            this.editfirstname = editfirstname;
            this.editmiddlename = editmiddlename;
            this.editlevel = editlevel;
            this.editcourse = editcourse;
            this.username = username;
 
            cmblevel.SelectedIndexChanged += new EventHandler(cmblevel_SelectedIndexChanged);
        }
        Class1 updatestudents = new Class1("127.0.0.1", "cs311c2024", "nathanielkester", "bueno");

        private void validateForm()
        {
            errorCount = 0;
            errorProvider1.Clear();
            if (string.IsNullOrEmpty(txtlastname.Text))
            {
                errorProvider1.SetError(txtlastname, "Last name is empty!");
                errorCount++;
            }
            if (string.IsNullOrEmpty(txtfirstname.Text))
            {
                errorProvider1.SetError(txtfirstname, "First name is empty!");
                errorCount++;
            }
            if (cmbcourse.SelectedIndex == -1)
            {
                errorProvider1.SetError(cmbcourse, "No course/strand selected!");
                errorCount++;
            }
            if (cmblevel.SelectedIndex < 0)
            {
                errorProvider1.SetError(cmblevel, "Select Level");
                errorCount++;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void cmbcourse_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void frmUpdateStudent_Load(object sender, EventArgs e)
        {
            txtstudentid.Text = editstudentID;
            txtlastname.Text = editlastname;
            txtfirstname.Text = editfirstname;
            txtmiddlename.Text = editmiddlename;
            cmblevel.SelectedItem = editlevel;

            // Trigger the level's selected index changed event to populate cmbSC
            cmblevel_SelectedIndexChanged(null, null);

            // Set the correct value for cmbSC (Strand/Course) after it's populated
            cmbcourse.SelectedValue = editcourse; // Select the value based on the saved code, not description

        }

      
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            validateForm();
            if (errorCount == 0)
            {
                // Confirmation message before proceeding with the update
                DialogResult dr = MessageBox.Show("Are you sure you want to update this Student?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    string selectedCourseCode = "N / A"; // Default to N / A if no course is selected

                    // Check if the level is SHS or COLLEGE, then use the selected value from cmbSC
                    if (cmblevel.SelectedItem.ToString() == "SHS" || cmblevel.SelectedItem.ToString() == "COLLEGE")
                    {
                        selectedCourseCode = cmbcourse.SelectedValue?.ToString(); // Use the selected course or strand code
                    }

                    // Update the student record with the new data
                    updatestudents.executeSQL("UPDATE tblstudents SET lastname = '" + txtlastname.Text + "', firstname = '" + txtfirstname.Text +
                            "', middlename = '" + txtmiddlename.Text + "', level = '" + cmblevel.Text + "', course = '" + selectedCourseCode +
                            "' WHERE studentID = '" + txtstudentid.Text + "'");

                    if (updatestudents.rowAffected > 0)
                    {
                        // Log the action if the update is successful
                        updatestudents.executeSQL("INSERT INTO tbllogs (datelog, timelog, action, module, ID, performedby) VALUES ('" +
                            DateTime.Now.ToShortDateString() + "', '" + DateTime.Now.ToShortTimeString() + "', 'UPDATE', 'Student Management', '" +
                            txtstudentid.Text + "', '" + username + "')");

                        MessageBox.Show("Student Information Successfully Updated", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close(); // Close the form after saving
                    }
                    else
                    {
                        MessageBox.Show("Failed to update the Student. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            errorProvider1.Clear();
            txtmiddlename.Clear();
            txtlastname.Clear();
            txtfirstname.Clear();
            txtmiddlename.Clear();
            cmblevel.SelectedIndex = -1;
            cmbcourse.SelectedIndex = -1;
        }
    }
}
